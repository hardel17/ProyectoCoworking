package com.mycompany.coworking;

import java.io.IOException;
import java.util.List;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet para listar todas las reservas existentes.
 */
@WebServlet("/listarReservas")
public class ListaReservasServlet extends HttpServlet {

    /**
     * Maneja las solicitudes GET para listar todas las reservas.
     * Recupera la lista de reservas desde el contexto del servlet y la envía al JSP.
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Obtener la lista de reservas desde el contexto del servlet
        ServletContext context = getServletContext();
        List<ReservaServlet.Reserva> reservas = (List<ReservaServlet.Reserva>) context.getAttribute("reservas");

        // Pasar la lista de reservas como un atributo al JSP
        request.setAttribute("reservas", reservas);

        // Redirigir al JSP que muestra la lista de reservas
        request.getRequestDispatcher("/Reservas.jsp").forward(request, response);
    }
}
