package com.mycompany.coworking;

import java.io.IOException;
import java.util.List;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet para eliminar una reserva específica de la lista de reservas.
 */
@WebServlet("/eliminarReserva")
public class EliminarReservaServlet extends HttpServlet {

    /**
     * Maneja las solicitudes GET para eliminar una reserva.
     * Valida el índice de la reserva a eliminar y actualiza la lista de reservas.
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Obtener el parámetro de índice de la URL
        String indexParam = request.getParameter("index");

        // Validar que el índice no sea nulo y sea un número válido
        if (indexParam == null || !indexParam.matches("\\d+")) {
            response.sendRedirect("listarReservas?error=Índice inválido");
            return;
        }

        // Convertir el índice a un entero
        int index = Integer.parseInt(indexParam);

        // Obtener el contexto del servlet y la lista de reservas
        ServletContext context = getServletContext();
        List<ReservaServlet.Reserva> reservas = (List<ReservaServlet.Reserva>) context.getAttribute("reservas");

        // Validar que la lista no sea nula y que el índice sea válido
        if (reservas != null && index >= 0 && index < reservas.size()) {
            // Eliminar la reserva en el índice especificado
            reservas.remove(index);
            context.setAttribute("reservas", reservas);
            response.sendRedirect("listarReservas?success=Reserva eliminada con éxito");
        } else {
            // Redirigir con un mensaje de error si el índice es inválido
            response.sendRedirect("listarReservas?error=Reserva no encontrada");
        }
    }
}
