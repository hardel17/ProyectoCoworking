package com.mycompany.coworking;

import java.io.IOException;
import java.net.URLEncoder;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/reservar")
public class ReservaServlet extends HttpServlet {

    /**
     * Clase interna que representa una Reserva.
     */
    public static class Reserva {
        private String nombre;
        private String fecha;
        private String espacio;
        private String horaInicio;
        private String horaFin;

        // Constructor para inicializar los atributos de la Reserva
        public Reserva(String nombre, String fecha, String espacio, String horaInicio, String horaFin) {
            this.nombre = nombre;
            this.fecha = fecha;
            this.espacio = espacio;
            this.horaInicio = horaInicio;
            this.horaFin = horaFin;
        }

        // Métodos getter para acceder a los atributos de la Reserva
        public String getNombre() {
            return nombre;
        }

        public String getFecha() {
            return fecha;
        }

        public String getEspacio() {
            return espacio;
        }

        public String getHoraInicio() {
            return horaInicio;
        }

        public String getHoraFin() {
            return horaFin;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Obtener los parámetros del formulario
        String nombre = request.getParameter("nombre");
        String fecha = request.getParameter("fecha");
        String espacio = request.getParameter("espacio");
        String horaInicio = request.getParameter("horaInicio");
        String horaFin = request.getParameter("horaFin");

        // Validación de campos vacíos
        if (nombre == null || nombre.isEmpty() ||
            fecha == null || fecha.isEmpty() ||
            espacio == null || espacio.isEmpty() ||
            horaInicio == null || horaInicio.isEmpty() ||
            horaFin == null || horaFin.isEmpty()) {
            response.sendRedirect("index.jsp?error=" + URLEncoder.encode("Todos los campos son obligatorios", "UTF-8"));
            return;
        }

        // Validar que la hora de fin sea posterior a la hora de inicio
        LocalTime inicio = LocalTime.parse(horaInicio);
        LocalTime fin = LocalTime.parse(horaFin);

        if (fin.isBefore(inicio)) {
            response.sendRedirect("index.jsp?error=" + URLEncoder.encode("La hora de fin debe ser posterior a la hora de inicio", "UTF-8"));
            return;
        }

        // Obtener la lista de reservas desde el contexto del servlet
        ServletContext context = getServletContext();
        List<Reserva> reservas = (List<Reserva>) context.getAttribute("reservas");

        // Si no hay una lista de reservas, crear una nueva
        if (reservas == null) {
            reservas = new ArrayList<>();
        }

        // Crear nueva reserva y agregarla a la lista
        Reserva nuevaReserva = new Reserva(nombre, fecha, espacio, horaInicio, horaFin);
        reservas.add(nuevaReserva);

        // Actualizar la lista de reservas en el contexto del servlet
        context.setAttribute("reservas", reservas);

        // Redirigir a la página de confirmación
        response.sendRedirect("Confirmacion_Reserva.jsp?nombre=" + URLEncoder.encode(nombre, "UTF-8") +
                              "&fecha=" + URLEncoder.encode(fecha, "UTF-8") +
                              "&espacio=" + URLEncoder.encode(espacio, "UTF-8") +
                              "&horaInicio=" + URLEncoder.encode(horaInicio, "UTF-8") +
                              "&horaFin=" + URLEncoder.encode(horaFin, "UTF-8"));
    }
}
